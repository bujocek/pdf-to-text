#include "StdAfx.h"
#include "StringObject.h"

StringObject::StringObject(char ** endKey, char * source)
{
  this->objectType = PdfObject::TYPE_STRING;
  source = StringUtils::skipWhiteSpace(source);
  if(*source == '<')
  {
    *endKey = strchr(source,'>');
    if(*endKey == null)
    {
      this->string = null;
      cerr << "\nStringObject: Couldn't recognize string in source.\n";
    }
    else
    {
      source += 1;
      int len = *endKey - source;
      this->string = new char[len + 1];
      strncpy(this->string, source, len);
      this->string[len] = 0;
      this->isHexa = true;
      *endKey += 1;
    }
  }
  else if(*source == '(')
  {
    *endKey = source;
    do
    {
      *endKey = strchr(*endKey+1,')');
    }while(*((*endKey)-1) == '\\' && *endKey != null);

    if(*endKey == null)
    {
      this->string = null;
      cerr << "\nStringObject: Couldn't recognize string in source.\n";
    }
    else
    {
      source += 1;
      int len = *endKey - source;
      this->string = new char[len + 1];
      strncpy(this->string, source, len);
      this->string[len] = 0;
      this->isHexa = false;
      *endKey += 1;
    }
  }
  else
  {
    cerr << "\nStringObject: No string object found in given source.\n";
  }
}

StringObject::~StringObject(void)
{
}
