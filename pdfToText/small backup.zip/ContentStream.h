#pragma once
#include "CommonHeader.h"
#include "pdfobject.h"
#include "IndirectObject.h"
#include "PageTreeNode.h"

class ContentStream :
  public PdfObject
{
public:
  IndirectObject * indirectObject;
  PageTreeNode * page;
  ContentStream(IndirectObject * io, PageTreeNode * page);
  ~ContentStream(void);
  char * getText();
};
