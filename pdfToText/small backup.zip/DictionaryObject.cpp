#include "StdAfx.h"
#include "DictionaryObject.h"
#include "StringUtils.h"
#include "string.h"
#include "NameObject.h"
#include "IndirectObjectRefference.h"

using namespace std;

DictionaryObject::DictionaryObject(char * startString, int length, char ** endKey)
{
  this->objectType = PdfObject::TYPE_DICTIONARY;
	this->dictionaryString = NULL;
  this->dictionaryStringLength = 0;
  if(length == -1)
    length = strlen(startString);
	//find dictionary
	char * dictionaryStart = StringUtils::strStrModified(startString, "<<", length);
  char * dictionaryEnd = NULL;
	if(dictionaryStart != NULL)
	{
    int restLength = length - (dictionaryStart - startString);
    int deep = 1;
    for(int i = 2; i < restLength-1; i++)
    {
      if(dictionaryStart[i] == '<' && dictionaryStart[i+1] == '<')
      {
        deep++;
        i++;
      }
      if(dictionaryStart[i] == '>' && dictionaryStart[i+1] == '>')
      {
        deep--;
        i++;
        if(deep == 0)
        {
          dictionaryEnd = dictionaryStart + i + 1;
          break;
        }
      }
    }
    if(dictionaryEnd == NULL)
    {
      cerr<<"\nDictionaryObject.cpp: Couldn't find end of dictionary.\n";
      return;
    }
    if(endKey != null)
      *endKey = dictionaryEnd;
    this->dictionaryStringLength = dictionaryEnd - dictionaryStart;
    this->dictionaryString = new char[this->dictionaryStringLength+1];
    strncpy( this->dictionaryString, dictionaryStart, this->dictionaryStringLength );
    this->dictionaryString[this->dictionaryStringLength] = 0;
    //find keys and values
    this->processDictionaryString();
	}
  else
  {
    cerr<<"\nDictionaryObject.cpp: Couldn't find begining of dictionary.\n";
  }
}

DictionaryObject::~DictionaryObject(void)
{
  //TODO: Delete name objects used for keys
}

void DictionaryObject::processDictionaryString()
{
  char * actualPos = this->dictionaryString;
  char * endKey = null;
  NameObject * key = null;
  PdfObject * value = null;
  do
  {
    key = NameObject::getNameObject(&endKey, actualPos);
    actualPos = endKey;
    if(key != null)
    {
      value = PdfObject::readValue(&endKey, actualPos);
      actualPos = endKey;
      dictionaryMap[key->name] = value;
    }
    actualPos = StringUtils::skipWhiteSpace(actualPos);
  }while(key != null && value != null && !(*actualPos == '>' && *(actualPos+1) == '>'));
}

PdfObject * DictionaryObject::getObject(char * mapKey)
{
  PdfObject * po = this->dictionaryMap[mapKey];
  if(po == null)
    return null;
  else if(po->objectType == PdfObject::TYPE_INDIRECT_OBJECT_REFFERENCE)
    return ((IndirectObjectRefference*) po)->getIndirectObject();
  else
    return po;
}