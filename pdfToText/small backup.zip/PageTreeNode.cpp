#include "StdAfx.h"
#include "PageTreeNode.h"

PageTreeNode::PageTreeNode(DictionaryObject * nodeDictionary)
{
  this->nodeDictionary = nodeDictionary;
  this->lookedForKids = false;
  this->isLeaf = false;
  this->parent = null;
  this->pageText = null;
  this->isPageProcessed = false;
  this->getKids();
}

PageTreeNode::~PageTreeNode(void)
{
}

inline list<PageTreeNode *> * badQuit()
{
  cerr << "\nPageTreeNode: Couldn't find kids of the node in dictionary.\n";
  return null;
}

list<PageTreeNode *> * PageTreeNode::getKids()
{
  if(!this->lookedForKids)
  {
    this->lookedForKids = true;
    PdfObject * po = this->nodeDictionary->getObject("/Kids");
    if(po == null)
    {
      this->isLeaf = true;
    }
    else
    {
      ArrayObject * ao = (ArrayObject*) po;
      if(ao == null)
        return badQuit();
      list<PdfObject *>::iterator objectListIterator;

      for ( objectListIterator = ao->objectList.begin(); objectListIterator != ao->objectList.end();
		        objectListIterator++)
      {
        if((*objectListIterator)->objectType == PdfObject::TYPE_INDIRECT_OBJECT_REFFERENCE)
        {
          IndirectObject * io = ((IndirectObjectRefference*)(*objectListIterator))->getIndirectObject();
          if(io == null)
            return badQuit();
          DictionaryObject * dictionary = (DictionaryObject*) io->getFirstObject();
          if(dictionary == null)
            return badQuit();
          PageTreeNode * ptn = new PageTreeNode(dictionary);
          ptn->parent = this;
          this->kids.push_back(ptn);
        }
        else
          return badQuit();
      }
    }
  }
  return &(this->kids);
}

void PageTreeNode::createPageList( list<PageTreeNode *> * pageList)
{
  if(this->isLeaf)
    pageList->push_back(this);
  else
  {
    list<PageTreeNode *>::iterator pageListIterator;
    for(pageListIterator = (this->getKids())->begin(); pageListIterator != (this->getKids())->end(); pageListIterator++)
      (*pageListIterator)->createPageList(pageList);
  }
}

void PageTreeNode::processPage()
{
  if(this->isPageProcessed)
    return;
  if(!this->isLeaf)
  {
    cerr << "\nPageTreeNode: Can't call process page method on non page tree node.\n";
    return;
  }
  PdfObject * contents = this->nodeDictionary->getObject("/Contents");
  ContentStream * cs;
  if(contents->objectType == PdfObject::TYPE_ARRAY)
  {
    list<PdfObject*> * objlist = &(((ArrayObject*) contents)->objectList);
    list<PdfObject*>::iterator oliterator;
    for(oliterator = objlist->begin(); oliterator != objlist->end(); oliterator++)
    {
      if((*oliterator)->objectType == PdfObject::TYPE_INDIRECT_OBJECT_REFFERENCE)
      {
        cs = new ContentStream(((IndirectObjectRefference*)(*oliterator))->getIndirectObject(),this);
        this->contents.push_back(cs);
      }
      else
        cerr<<"\nPageTreeNode: Unexpected object found in contents array\n";
    }
    this->isPageProcessed = true;
    return;
  }
  else if(contents->objectType == PdfObject::TYPE_INDIRECT_OBJECT)
  {
    cs = new ContentStream((IndirectObject*)contents, this);
    this->contents.push_back(cs);
    this->isPageProcessed = true;
    return;
  }
  else
  {
    cerr << "\nPageTreeNode: Unsupported Content in page dictionary.\n";
    this->isPageProcessed = true;
    return;
  }
}

void PageTreeNode::getText(ofstream& file)
{
  list<ContentStream*>::iterator csi;
  for(csi = this->contents.begin(); csi != this->contents.end(); csi++)
  {
    file << (*csi)->getText();
  }
}