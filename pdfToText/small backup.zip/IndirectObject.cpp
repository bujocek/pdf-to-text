#include "StdAfx.h"
#include "XRef.h"
#include "IndirectObject.h"
#include "NumberObject.h"
#include "NameObject.h"
#include "IndirectObjectRefference.h"
#include <iostream>
#include <fstream>
#include <queue>
#include <deque>
#include "zlib.h"
#include "StringUtils.h"

using namespace std;

IndirectObject::IndirectObject(tableRow row, int objectNum, ifstream& iFile)
{
  this->objectType = PdfObject::TYPE_INDIRECT_OBJECT;
	this->isProcessed = false;
	this->isLoaded = false;
	this->objectStringSize = -1;
	this->objectString = null;
  this->firstObject = null;
	this->objectNumber = objectNum;
  this->streamDictionary = null;
	this->objectState = char(row[17]); //reed 'f' or 'n' - it's on fixed position 17
	this->file = &iFile;
	char * e;
	if(this->objectState == IN_USE_OBJECT)
	{
		e = &row[10];
		this->nextFreeObject = -1;
		this->byteOffset = strtol(row, &e, 10);
	}
	if(this->objectState == FREE_OBJECT)
	{
		e = &row[10];
		this->byteOffset = -1;
		this->nextFreeObject = strtol(row, &e, 10);
	}
	e = &row[16];
	this->generationNumber = int(strtol(&row[11], &e, 10));
}

bool IndirectObject::load()
{
	//find object in file
	if(this->isLoaded)
		return true;
	if(this->file != null && this->byteOffset > 0)
	{
		//read entire object into the memory
		//find obj and endobj keywords
		queue<char*, deque<char*>> blockQueue;
		int blockSize = 128;
		char * prevBlock = null;
		char * block = null;
		char * endobj = null;
		this->file->clear();
		this->file->seekg(this->byteOffset);
		while(endobj == null)
		{
			prevBlock = block;
			block = new char[blockSize];
			if(this->file->eof())
			{
				cerr<<"\nPdfObject: Couldn't find endobj of " << this->objectNumber << " object. (Input file eof)";
				return false;
			}
			this->file->read(block, blockSize-1);
			if(this->file->fail())
			{
				cerr<<"\nPdfObject: Couldn't find endobj of " << this->objectNumber << " object. (Input file fail)";
				return false;
			}
			block[blockSize-1] = 0; //end this string
			blockQueue.push(block);	
			
			//check if 'endobj' is between blocks
			if(endobj == null && prevBlock != null)
			{
				char joinedBlocks[11];
				memcpy(joinedBlocks, &prevBlock[blockSize-6], 5);
				memcpy(&joinedBlocks[5], block, 5);
				joinedBlocks[10] = 0;
				endobj = StringUtils::strStrModified(joinedBlocks, "endobj", 11);
				if(endobj != null)
				{
					int positionInJoined = endobj - joinedBlocks;
					endobj = &block[positionInJoined -5 +6];
				}
			}

			if(endobj == null)
			{
				endobj = StringUtils::strStrModified(block, "endobj", blockSize);
				if(endobj != null)
					endobj += 6;
			}
		} 
		this->objectStringSize = ( (int) blockQueue.size() - 1)*(blockSize-1) + (endobj - block);
		this->objectString = new char[this->objectStringSize+1];
		char * index = this->objectString;
		while((int) blockQueue.size() > 1)
		{
			block = blockQueue.front();
			memcpy(index, block, blockSize -1);
			index += blockSize -1;
			delete block;
			blockQueue.pop();
		}
		block = blockQueue.front();
		memcpy(index, block, (endobj - block));
		blockQueue.pop();
    this->objectString[this->objectStringSize] = 0;
		if(logEnabled)
			clog << "\nObject " << this->objectNumber << " loaded into memory.";
		this->isLoaded = true;
		return true;
	}
	return false;
}

bool IndirectObject::processAsStream()
{
	if(this->isProcessed)
		return true;
	
	if(this->objectStringSize > 0)
	{
		this->unencodedStream = null;
		this->unencodedStreamSize = -1;
		char * streamString = StringUtils::strStrModified(this->objectString, "stream", this->objectStringSize);
		if(streamString != null)
		{
			streamString+=6;
			char * endstreamString = StringUtils::strStrModified(this->objectString, "endstream", this->objectStringSize);
			if(endstreamString != null)
			{
				//Stream found
				if(streamString < endstreamString)
				{
					//remove newlines and lineFeeds after streamStart  and before streamEnd keywords
					//so between pointers is just byte stream
					if (*streamString == '\r' && *(streamString+1) == '\n')
						streamString+=2;
					else if (*streamString == '\n')
						streamString++;
					if (*(endstreamString-2) == '\r' && *(endstreamString-1) == '\n')
						endstreamString-=2;
					else if (*(endstreamString-1) == '\n')
						endstreamString--;

					if(logEnabled)
						clog << "\nStream found in object " << this->objectNumber;
					
					//Find dictionary and find used filter
          PdfObject * fo = this->getFirstObject();
          if(fo->objectType == PdfObject::TYPE_DICTIONARY)
            this->streamDictionary = (DictionaryObject*) fo;
          else
          {
            cerr << "\nIndirectObject: Couldn't read stream dictionary in object " << this->objectNumber <<
							". \nSkipping this invalid pdf stream object.\n";
            return false;
          }

          //Find length of the stream
          PdfObject * lengthObject = this->streamDictionary->getObject("/Length");
          if(lengthObject == null)
					{
						cerr << "\nPdfObject: Couldn't find stream length in dictionary of object " << this->objectNumber <<
							". \nSkipping this invalid pdf stream object.";
						return false;
					}
          long lengthNumber = -1;
          if(lengthObject->objectType == PdfObject::TYPE_NUMBER)
          {
            lengthNumber = (long) ((NumberObject*) lengthObject)->number;
          }
          if(lengthObject->objectType == PdfObject::TYPE_INDIRECT_OBJECT) 
          {
            IndirectObject * po = (IndirectObject*)lengthObject;
						if(!po->isProcessed)
						{
							po->processAsStream();
						}
						lengthNumber = po->getNumber();
						if(lengthNumber == 0)
						{
							cerr << "\nCouldn't get indirect length parameter for stream in object" << this->objectNumber <<".";
							return false;
						}
					}
					if(lengthNumber != (endstreamString - streamString)) // just for sure that pointers and length match
					{
						cerr << "\nPdfObject: Possible problem with determining stream\n and length of stream in object " <<
						this->objectNumber << "\n Length from dictionary is: " << lengthNumber <<
						"\n Length between stream and endstream is: " << (endstreamString - streamString) << "\n";
						//correcting endstreamString
						endstreamString = streamString + lengthNumber;
					}
          
          //Find used filter for the stream
          PdfObject * filterObject = this->streamDictionary->getObject("/Filter");
          if(filterObject == null)
					{
					  //than it is unencoded stream (not so common case)
						this->unencodedStream = streamString;
						this->unencodedStreamSize = lengthNumber;
					}
					else
					{
						//TODO: Rewrite to enable decoding more filters in stream
						//If filter is not array and is flate decode than decode it
            if(filterObject->objectType == PdfObject::TYPE_NAME && strcmp(((NameObject *) filterObject)->name, "/FlateDecode") == 0)
            {
							this->unencodedStreamSize = this->deflateStream(streamString, 
								endstreamString, &this->unencodedStream);
							if(logEnabled)
								clog << "\nStream successfully decoded by FlateDecode.";
						}
						else
						{
							cerr << "\nPdfObject: Not implemented: \n Unsupported filters in stream of object " <<
							this->objectNumber << ". \n Skipping this object.";
							return false;
						}
					}
				}
			}
		}
		this->isProcessed = true;
		return true;
	}
	return false;
}

long IndirectObject::deflateStream(char * streamStart, char * streamEnd, char ** output)
{
	//TODO: optimize output size -try to unpack per partes / not 10x input length
	long outsize = (streamEnd - streamStart)*10; //assuming that output will not be bigger than ten times input

  if(this->streamDictionary != null && this->streamDictionary->getObject("DL") != null) 
  {
    if(this->streamDictionary->getObject("DL")->objectType == PdfObject::TYPE_NUMBER)
      outsize = (long)((NumberObject*) this->streamDictionary->getObject("DL"))->number;
    else if(this->streamDictionary->getObject("DL")->objectType == PdfObject::TYPE_INDIRECT_OBJECT)
    {
      IndirectObject * io = (IndirectObject *) this->streamDictionary->getObject("DL");
      if(io != null)
        outsize = io->getNumber();
    }
  }

	char * out = new char [outsize]; 
	z_stream zstrm;
	memset(&zstrm, 0, sizeof(zstrm));
	
	zstrm.avail_in = streamEnd - streamStart + 1;
	zstrm.avail_out = outsize;
	zstrm.next_in = (Bytef*)(streamStart);
	zstrm.next_out = (Bytef*)out;

	int rsti = inflateInit(&zstrm);
	if (rsti == Z_OK)
	{
		int rst2 = inflate(&zstrm, Z_FINISH);
		if (rst2 >= 0)
		{
			//Ok, got something
			*output = new char [zstrm.total_out];
			memcpy(*output, out, zstrm.total_out);
			delete[] out;
			return zstrm.total_out;
		}
	}

	//if something went wrong
	delete[] out;
	return -1;
}

long IndirectObject::getNumber()
{
	if(this->isLoaded)
	{
		if(this->unencodedStream != null)
		{
			//TODO: find number in unencoded string (maybe useless)
			cerr << "\nIndirectObject: Not implemented: \n Number is in indirect object encoded in stream.\n";
			return 0;
		}
		else
		{
			char * obj = strstr(this->objectString, "obj"); //skip object numbers
			obj+=3;
			return strtol(obj,null,0);
		}
	}
	return 0;
}

char * IndirectObject::getText()
{
	char * usingString;
	int usingStringLen;
	if(this->unencodedStreamSize > 0)
	{
		usingString = this->unencodedStream;
		usingStringLen = this->unencodedStreamSize;
	}
	else if(this->objectStringSize > 0)
	{
		usingString = this->objectString;
		usingStringLen = this->objectStringSize;
	}
	else
		return "";

	//search for BT and ET
	char * bt = null;
	char * et = null;
	char * str;
	queue<char *, deque<char*>> strings;
	long resultSize = 0;
	do
	{
		bt = StringUtils::strStrModified(usingString, "BT", usingStringLen);
		et = null;
		if(bt != null)
			et = StringUtils::strStrModified(bt, "ET", usingStringLen - (bt - usingString));
		if(et != null)
		{
			et += 2;
			str = new char[et-bt+1];
			strncpy(str,bt,et-bt);
			str[et-bt] = 0;
			resultSize += et-bt;
			strings.push(str);
		}
		usingStringLen = usingString - et;
		usingString = et;
	} while(bt != null);
	
	if(logEnabled && strings.size() > 0)
		clog << "\nFound text object(s) in pdf object " << this->objectNumber << ".\nExtracting...";

	char * resultString = new char[resultSize+1];
	resultString[0] = 0;
	while(strings.size() > 0)
	{
		str = this->processTextObject(strings.front());
		strcat(resultString, str);
		delete[] str;
		strings.pop();
	}
	if(logEnabled && resultSize > 0)
		clog << "\nSomething extracted.";
	resultString[resultSize] = 0;
	return resultString;
}

char * IndirectObject::processTextObject(char * textObject)
{
	int len = strlen(textObject);
	int i =0;
	char * begin = null;
	char * end;
	char * result = new char[len];
	result[0] = 0;
	bool hexa = false;
	int deep = 0;
	for(;i<len; i++)
	{
    //New line operators adding
    if(textObject[i] == 'T' && deep == 0)
    {
      switch(textObject[i+1])
      {
      case 'd':
      case 'D':
      case '*':
        strncat(result,"\n",1);
      }
    }
    if((textObject[i] == '\'' || textObject[i] == '"') && deep == 0)
    {
      strncat(result,"\n",1);
    }

		if(textObject[i] == '(')
		{
			if(deep>0)
			{
				deep++;
			}
			if(deep==0)
			{
				hexa = false;
				deep++;
				begin = &textObject[i];
			}
		}
		if(textObject[i] == ')' && textObject[i-1] != '\\')
		{
			if(deep>0)
			{
				deep--;
			}
			if(deep==0)
			{
				end = &textObject[i];
        if(begin == null)
        {
          cerr<<"\nIndirectObject: Problem in finding strings. Probably not text object.\n";
          return result;
        }
				//TODO: process string between begin and end
				strncat(result, begin+1, end-begin-1);
			}
		}
		if(textObject[i] == '<')
		{
			if(deep==0)
			{
				hexa = true;
				deep++;
				begin = &textObject[i];
			}
		}
		if(textObject[i] == '>')
		{
			if(deep==1 && hexa)
			{
				deep--;
				end = &textObject[i];
				//TODO: use font maps for determining chars from string
				char * convertedString = hexaStringToCString(begin+1, end - begin -1);
				strcat(result, convertedString);
				delete[] convertedString;
				//strncat(result, begin, end-begin+1);
			}
		}
	}
	return result;
}

/**
helper function for hexaStringToCString
*/
char hexaCharToChar(char h1, char h2)
{
	char hexa[3];
	hexa[0] = h1;
	hexa[1] = h2;
	hexa[2] = 0;
	int charCode = strtol(hexa, null, 16);
	return charCode;
}

char * IndirectObject::hexaStringToCString(char * source, int length)
{
	char * newString = new char[length/2+1];
	for(int i=0; i<length; i+=2)
	{
		if(i+1 >= length)
			newString[i/2] = hexaCharToChar(source[i], '0'); //add '0' char at the end if it is not even count of chars
		else
			newString[i/2] = hexaCharToChar(source[i], source[i+1]);
	}
	newString[length/2] = 0;
	return newString;
}

PdfObject * IndirectObject::getFirstObject()
{
  if(this->firstObject == null)
  {
    char * string = this->objectString;
    string = strstr(string, "obj");
    string += 3;
    string = StringUtils::skipWhiteSpace(string);
    this->firstObject = PdfObject::readValue(null, string);
  }
  return this->firstObject;
}

IndirectObject::~IndirectObject(void)
{
}