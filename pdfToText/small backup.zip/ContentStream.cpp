#include "StdAfx.h"
#include "ContentStream.h"

ContentStream::ContentStream(IndirectObject * io, PageTreeNode * page)
{
  this->objectType = PdfObject::TYPE_CONTENT_STREAM;
  this->indirectObject = io;
  this->page = page;
  this->indirectObject->processAsStream();
}

ContentStream::~ContentStream(void)
{
}

char * ContentStream::getText()
{
  return this->indirectObject->getText();
}
