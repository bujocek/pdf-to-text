#pragma once
#include "pdfobject.h"

class StringObject :
  public PdfObject
{
public:
  bool isHexa;
  char * string;
  StringObject(char ** endKey, char * source);
  ~StringObject(void);
};
