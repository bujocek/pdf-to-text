#pragma once
#include "XRef.h"
#include "PdfObject.h"

#include <iostream>
#include <fstream>
#include <map>

using namespace std;

#define IN_USE_OBJECT 'n'
#define FREE_OBJECT 'f'

class IndirectObject : public PdfObject
{
private:
	ifstream * file;
	bool isProcessed;
	bool isLoaded;
  PdfObject * firstObject;

	/**
	retrieves text from textObject found in this pdf object
	*/
	char * processTextObject(char * textObject);
	
	/**
	converts the hexa string in source to CString
	creates new string and returns it
	*/
	char * hexaStringToCString(char * source, int length);

public:
	char objectState;
	char * objectString;
	long objectStringSize;
	char * unencodedStream;
	long unencodedStreamSize;
	int objectNumber;
	long byteOffset;
	long nextFreeObject;
	int generationNumber;
  DictionaryObject * streamDictionary;

	/**
	loads object from file to memory
	*/
	bool load();

	/**
	Processes loaded object. Finds stream if present and decodes it.
	load() must be called first
	*/
	bool processAsStream();

	/**
	deflates stream defined between streamStart and streamEnd and returns deflated result as a string
	*/
	long deflateStream(char * streamStart, char * streamEnd, char ** output);

	IndirectObject(tableRow row, int objectNum, ifstream& iFile);
	~IndirectObject(void);

	/**
	tries to retrieve number from Pdf object if it is numeric object
	*/
	long getNumber();

	/**
	tries to retrieve text from Pdf object if there is some
	*/
	char * getText();
  
  /**
  returns first pdf object found after "nn mm obj" in object string
  */
  PdfObject * getFirstObject();
};
