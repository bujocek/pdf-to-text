var searchData=
[
  ['gz_5fheader_5fs',['gz_header_s',['../structgz__header__s.html',1,'']]]
];
