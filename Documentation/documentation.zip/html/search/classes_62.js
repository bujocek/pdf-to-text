var searchData=
[
  ['bfrange',['bfrange',['../structbfrange.html',1,'']]],
  ['boolobject',['BoolObject',['../class_bool_object.html',1,'']]]
];
