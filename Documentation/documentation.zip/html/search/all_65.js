var searchData=
[
  ['end',['end',['../structbfrange.html#afc88d0a38ea4179c3e7d9c4fbae0e1fc',1,'bfrange']]]
];
