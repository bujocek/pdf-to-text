var searchData=
[
  ['boolobject',['BoolObject',['../class_bool_object.html#add3f5b789a987d69101ebaa8427876f1',1,'BoolObject::BoolObject(bool value)'],['../class_bool_object.html#a54cfeb78aed9f49049a20b3fe21e2d98',1,'BoolObject::BoolObject(char **endKey, char *source)']]]
];
