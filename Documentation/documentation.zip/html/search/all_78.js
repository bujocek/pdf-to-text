var searchData=
[
  ['xref',['XRef',['../class_x_ref.html',1,'XRef'],['../class_x_ref.html#a5114c492a9a30d3f9a5a40154577d048',1,'XRef::XRef()']]],
  ['xrefsubsection',['XRefSubsection',['../struct_x_ref_subsection.html',1,'']]]
];
