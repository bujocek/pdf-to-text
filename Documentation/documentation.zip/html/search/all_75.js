var searchData=
[
  ['unencodedstream',['unencodedStream',['../class_indirect_object.html#a7f9f64b9f09b83dc25bca692b665c1a5',1,'IndirectObject']]],
  ['unencodedstreamsize',['unencodedStreamSize',['../class_indirect_object.html#a661f1f35ef1d6fa934752a7ca6b810ae',1,'IndirectObject']]]
];
