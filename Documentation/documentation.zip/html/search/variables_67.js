var searchData=
[
  ['generationnumber',['generationNumber',['../class_indirect_object.html#a62d28a4b7cdfa510f9d72a47ecdd0226',1,'IndirectObject::generationNumber()'],['../class_indirect_object_reference.html#a31978b38a9d2d78f9952cad899524bea',1,'IndirectObjectReference::generationNumber()']]]
];
