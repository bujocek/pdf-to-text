var searchData=
[
  ['file',['file',['../class_x_ref.html#a23f437bee83f5bd56a5b94b1095d5299',1,'XRef']]],
  ['firstobjectnumber',['firstObjectNumber',['../struct_x_ref_subsection.html#aa93ef7c8d7a7287a1d02d0f2a1a426cc',1,'XRefSubsection']]]
];
