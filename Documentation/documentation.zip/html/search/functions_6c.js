var searchData=
[
  ['load',['load',['../class_indirect_object.html#a49bbd6ccd1f8576635fb9ce4374b2478',1,'IndirectObject']]]
];
